import React, { useState } from "react";
import { FaEye, FaGoogle, FaLinkedin, FaUser, FaLock } from "react-icons/fa";
import loginImage from "../assets/loginimage.png";
import './Login.css';
import API from "../services/api";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async () => {
    try {
      const res = await API.post("/auth/login", { email, password });
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("role", res.data.user.role);
      window.location.href = res.data.user.role === "admin" ? "/admin" : "/customer";
    } catch (err) {
      alert("Login failed!");
    }
  };

  return (
    <div className="login-container">
      <div className="login-bg"></div>
      <div className="login-card">
        <h2>GeoLoyaltyAI</h2>
        <div className="input-group">
          <FaUser className="input-icon" />
          <input 
            type="email" 
            placeholder="Email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
          />
        </div>
        <div className="input-group">
          <FaLock className="input-icon" />
          <input 
            type={showPassword ? "text" : "password"} 
            placeholder="Password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
          />
          <FaEye className="eye-icon" onClick={() => setShowPassword(!showPassword)} />
        </div>
        <p className="forgot-link" onClick={() => alert("Reset password flow")}>Forgot Password?</p>
        <button className="login-btn" onClick={handleLogin}>Login</button>
        <div className="social-login">
          <button className="google-btn"><FaGoogle /> Continue with Google</button>
          <button className="linkedin-btn"><FaLinkedin /> Continue with LinkedIn</button>
        </div>
        <p className="register-link" onClick={() => window.location.href="/register"}>
          Don't have an account? Register
        </p>
      </div>
    </div>
  );
}
