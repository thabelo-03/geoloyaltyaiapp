// src/components/CustomerDashboard.js
import React, { useState, useEffect } from "react";
import {
  FaCoins,
  FaMedal,
  FaHistory,
  FaGift,
  FaUserCircle,
  FaCog,
  FaSignOutAlt,
  FaRobot,
} from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import "./CustomerDashboard.css";

export default function CustomerDashboard() {
  const [wallet, setWallet] = useState({
    points: 42,
    tier: "Silver",
    history: [
      { action: "Checked in", points: 5 },
      { action: "Redeemed Coupon", points: -10 },
      { action: "Referral Bonus", points: 15 },
    ],
    rewardsRedeemed: 2,
  });
  const [showAllHistory, setShowAllHistory] = useState(false);
  const [modalInfo, setModalInfo] = useState(null);
  const [menuModalOpen, setMenuModalOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchWallet = async () => {
      try {
        const res = await API.get("/wallets/me", {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        if (res.data.wallet) setWallet(res.data.wallet);
      } catch (err) {
        console.error("API failed, using default data", err);
      }
    };
    fetchWallet();
  }, []);

  const walletPoints = wallet.points ?? 0;
  const walletTier = wallet.tier ?? "Bronze";
  const walletHistory = Array.isArray(wallet.history) ? wallet.history : [];
  const walletRewards = wallet.rewardsRedeemed ?? 0;
  const tierProgress = walletPoints % 100;
  const historyToShow = showAllHistory ? walletHistory : walletHistory.slice(-3);

  const openModal = (title, description) => setModalInfo({ title, description });
  const closeModal = () => setModalInfo(null);

  return (
    <>
      {/* Header */}
      <header className="dashboard-header">
        <h1>Customer Dashboard</h1>
        <div style={{ display: "flex", gap: "10px" }}>
          <button
            className="ai-header-btn"
            onClick={() => navigate("/ai")}
          >
            View AI Insights
          </button>
          <button
            className="ai-header-btn"
            onClick={() => setMenuModalOpen(true)}
            style={{ background: "#6b7280" }}
          >
            ☰
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="dashboard scrollable">
        {/* AI Insights Card */}
        <div
          className="ai-insights-card pressable"
          onClick={() => navigate("/ai")}
        >
          <FaRobot className="ai-icon" />
          <div className="insight-text">
            Welcome! Your next reward is waiting, keep engaging.
          </div>
        </div>

        {/* Points Card */}
        <div
          className="card pressable"
          onClick={() =>
            openModal("Points", `You have ${walletPoints} points.`)
          }
        >
          <div className="card-header">
            <FaCoins className="icon points" style={{ color: "#3b82f6", fontSize: "2rem" }} />
            <h3>Points</h3>
          </div>
          <p className="card-value">{walletPoints}</p>
          <div className="progress-bar">
            <div className="progress" style={{ width: `${tierProgress}%` }}></div>
          </div>
          <small>{tierProgress} pts to next tier</small>
        </div>

        {/* Tier Card */}
        <div
          className="card pressable"
          onClick={() =>
            openModal("Tier", `You are currently in the ${walletTier} tier.`)
          }
        >
          <div className="card-header">
            <FaMedal className="icon tier" style={{ color: "#a855f7", fontSize: "2rem" }} />
            <h3>Tier</h3>
          </div>
          <span className={`tier-badge ${walletTier.toLowerCase()}`}>{walletTier}</span>
        </div>

        {/* Engagements Card */}
        <div
          className="card pressable"
          onClick={() =>
            openModal("Engagements", `You have ${walletHistory.length} total engagements.`)
          }
        >
          <div className="card-header">
            <FaHistory className="icon engagement" style={{ color: "#f59e0b", fontSize: "2rem" }} />
            <h3>Engagements</h3>
          </div>
          <p className="card-value">{walletHistory.length}</p>
        </div>

        {/* Rewards Redeemed Card */}
        <div
          className="card pressable"
          onClick={() =>
            openModal("Rewards Redeemed", `You have redeemed ${walletRewards} rewards.`)
          }
        >
          <div className="card-header">
            <FaGift className="icon reward" style={{ color: "#10b981", fontSize: "2rem" }} />
            <h3>Rewards Redeemed</h3>
          </div>
          <p className="card-value">{walletRewards}</p>
        </div>

        {/* Recent Activities */}
        <div className="card pressable">
          <h3>Recent Activities</h3>
          <ul className="engagement-list">
            {historyToShow.map((event, idx) => (
              <li key={idx}>
                <span>{event.action}</span>
                <span style={{ color: event.points > 0 ? "#10b981" : "#dc2626" }}>
                  {event.points > 0 ? `+${event.points}` : event.points}
                </span>
              </li>
            ))}
          </ul>
          {walletHistory.length > 3 && (
            <button className="view-more" onClick={() => setShowAllHistory(!showAllHistory)}>
              {showAllHistory ? "View Less" : "View More"}
            </button>
          )}
        </div>
      </main>

      {/* Info Modal */}
      {modalInfo && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h2>{modalInfo.title}</h2>
            <p>{modalInfo.description}</p>
            <button onClick={closeModal}>Close</button>
          </div>
        </div>
      )}

      {/* Menu Modal */}
      {menuModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h2>Menu</h2>
            <button><FaUserCircle /> Profile</button>
            <button><FaCog /> Settings</button>
            <button className="logout" onClick={() => alert("Logged out")}><FaSignOutAlt /> Logout</button>
            <button onClick={() => setMenuModalOpen(false)}>Close</button>
          </div>
        </div>
      )}
    </>
  );
}
