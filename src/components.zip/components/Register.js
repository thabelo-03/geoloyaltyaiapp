import React, { useState } from "react";
import { FaUser, FaLock, FaEnvelope, FaEye } from "react-icons/fa";
import './Register.css';
import API from "../services/api";

export default function Register() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [errors, setErrors] = useState({});

  const handleRegister = async () => {
    setErrors({}); // Clear previous errors

    if (!agreeTerms) {
      setErrors({ terms: "You must accept the Terms and Conditions" });
      return;
    }

    try {
      const res = await API.post("/auth/register", { firstName, lastName, email, password });

      // Show success modal
      setModalMessage("Registration successful! You can now login.");
      setModalVisible(true);

    } catch (err) {
      // Parse backend error
      const msg = err.response?.data?.error || "Registration failed!";
      
      setErrors({ general: msg });
    }
  };

  const handleModalClose = () => {
    setModalVisible(false);
    window.location.href = "/";
  };

  return (
    <div className="register-container">
      <div className="register-bg"></div>
      <div className="register-card">
        <h2>Create Account</h2>

        <div className="input-group">
          <FaUser className="input-icon" />
          <input 
            type="text" 
            placeholder="First Name" 
            value={firstName} 
            onChange={(e) => setFirstName(e.target.value)} 
          />
        </div>

        <div className="input-group">
          <FaUser className="input-icon" />
          <input 
            type="text" 
            placeholder="Last Name" 
            value={lastName} 
            onChange={(e) => setLastName(e.target.value)} 
          />
        </div>

        <div className="input-group">
          <FaEnvelope className="input-icon" />
          <input 
            type="email" 
            placeholder="Email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
          />
        </div>

        <div className="input-group">
          <FaLock className="input-icon" />
          <input 
            type={showPassword ? "text" : "password"} 
            placeholder="Password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
          />
          <FaEye className="eye-icon" onClick={() => setShowPassword(!showPassword)} />
        </div>

        <div className="terms-checkbox" style={{ margin: "15px 0" }}>
          <input 
            type="checkbox" 
            checked={agreeTerms} 
            onChange={(e) => setAgreeTerms(e.target.checked)} 
          />
          <label>
            I agree to the <a href="/terms" target="_blank">Terms & Conditions</a>
          </label>
          {errors.terms && <p className="error-text">{errors.terms}</p>}
        </div>

        {errors.general && <p className="error-text">{errors.general}</p>}

        <button className="register-btn" onClick={handleRegister}>Register</button>

        <p className="login-link" onClick={() => window.location.href="/"}>
          Already have an account? Login
        </p>
      </div>

      {/* Success Modal */}
      {modalVisible && (
        <div className="modal-overlay">
          <div className="modal-content">
            <p>{modalMessage}</p>
            <button onClick={handleModalClose}>OK</button>
          </div>
        </div>
      )}
    </div>
  );
}
