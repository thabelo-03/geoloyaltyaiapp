// src/components/AdminDashboard.js
import React, { useState, useEffect } from "react";
import {
  FaUsers,
  FaBuilding,
  FaChartPie,
  FaCogs,
  FaFileAlt,
  FaBrain,
} from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import "./AdminDashboard.css";

export default function AdminDashboard() {
  const [tenantName, setTenantName] = useState("");
  const [insightIndex, setInsightIndex] = useState(0);
  const [modalInfo, setModalInfo] = useState(null); // info for modal
  const navigate = useNavigate();

  const insights = [
    "🔮 Predictions show +12% tenant growth next month.",
    "⚡ System health is Optimal.",
    "📊 User engagement up by 18% this week.",
    "🤖 AI detected 3 anomalies in tenant activities.",
    "🚀 Revenue forecast +25% for the next quarter.",
  ];

  // Rotate AI insights every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setInsightIndex((prev) => (prev + 1) % insights.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const createTenant = async () => {
    if (!tenantName) return alert("Enter a tenant name");
    try {
      await API.post("/tenants", { name: tenantName });
      alert("Tenant created!");
      setTenantName("");
    } catch (err) {
      console.error(err);
      alert("Error creating tenant");
    }
  };

  const openModal = (title, description, Icon) => {
    setModalInfo({ title, description, Icon });
  };

  const closeModal = () => setModalInfo(null);

  return (
    <div className="admin-dashboard scrollable">
      {/* HEADER */}
      <header className="dashboard-header">
        <h1>⚡ Admin Dashboard</h1>
        <p>AI Powered Control Center</p>
      </header>

      {/* AI INSIGHTS CARD */}
      <div className="ai-insights-card">
        <FaBrain className="ai-icon" />
        <div>
          <h2>AI Insights</h2>
          <p className="insight-text">{insights[insightIndex]}</p>
          <button onClick={() => navigate("/ai")}>View AI Insights</button>
        </div>
      </div>

      {/* MANAGEMENT CARDS GRID */}
      <div className="management-grid">
        {/* Tenant Management */}
        <div
          className="management-card pressable"
          onClick={() =>
            openModal(
              "Tenant Management",
              "Create, view, and manage tenants across your system.",
              FaBuilding
            )
          }
        >
          <FaBuilding className="icon" />
          <h3>Tenant Management</h3>
          <input
            type="text"
            placeholder="Enter tenant name"
            value={tenantName}
            onChange={(e) => setTenantName(e.target.value)}
          />
          <button onClick={createTenant}>Create Tenant</button>
        </div>

        {/* User Management */}
        <div
          className="management-card pressable"
          onClick={() =>
            openModal(
              "User Management",
              "View and manage users for all tenants.",
              FaUsers
            )
          }
        >
          <FaUsers className="icon" />
          <h3>User Management</h3>
          <p>View and manage users for all tenants.</p>
          <button>Manage Users</button>
        </div>

        {/* Analytics */}
        <div
          className="management-card pressable"
          onClick={() =>
            openModal(
              "Analytics",
              "Visualize system usage, performance metrics, and trends.",
              FaChartPie
            )
          }
        >
          <FaChartPie className="icon" />
          <h3>Analytics</h3>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: "75%" }}></div>
          </div>
          <p>System Usage: 75%</p>
          <button>View Analytics</button>
        </div>

        {/* System Settings */}
        <div
          className="management-card pressable"
          onClick={() =>
            openModal(
              "System Settings",
              "Configure global preferences, security, and system options.",
              FaCogs
            )
          }
        >
          <FaCogs className="icon" />
          <h3>System Settings</h3>
          <p>Configure global preferences and security.</p>
          <button>Open Settings</button>
        </div>

        {/* AI Reports */}
        <div className="management-card pressable">
          <FaFileAlt className="icon" />
          <h3>AI Reports</h3>
          <div className="progress-bar">
            <div className="progress-fill report" style={{ width: "50%" }}></div>
          </div>
          <p>Report Generation: 50%</p>
          <button onClick={() => navigate("/ai")}>View AI Reports</button>
        </div>
      </div>

      {/* MODAL */}
      {modalInfo && (
        <div className="modal-overlay">
          <div className="modal-content">
            <modalInfo.Icon className="modal-icon" />
            <h2>{modalInfo.title}</h2>
            <p>{modalInfo.description}</p>
            <button onClick={closeModal}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
